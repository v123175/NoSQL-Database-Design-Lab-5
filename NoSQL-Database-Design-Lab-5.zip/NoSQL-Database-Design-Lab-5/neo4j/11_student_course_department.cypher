CREATE CONSTRAINT student_id IF NOT EXISTS
FOR (s:Student) REQUIRE s.student_id IS UNIQUE;

CREATE CONSTRAINT course_id IF NOT EXISTS
FOR (c:Course) REQUIRE c.course_id IS UNIQUE;

CREATE CONSTRAINT department_id IF NOT EXISTS
FOR (d:Department) REQUIRE d.department_id IS UNIQUE;

CREATE (d:Department {department_id: "D01", name: "Computer Science"});
CREATE (c1:Course {course_id: "C01", name: "DBMS"});
CREATE (c2:Course {course_id: "C02", name: "Python"});
CREATE (s1:Student {student_id: "S01", name: "Aman", year: 2});
CREATE (s2:Student {student_id: "S02", name: "Riya", year: 2});

MATCH (s:Student {student_id: "S01"}), (c:Course {course_id: "C01"})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {student_id: "S02"}), (c:Course {course_id: "C02"})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (c:Course), (d:Department {department_id: "D01"})
CREATE (c)-[:OFFERED_BY]->(d);

MATCH (n)-[r]->(m) RETURN n, r, m;
