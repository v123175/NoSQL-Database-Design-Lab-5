CREATE (p1:Person {name: "Aman"});
CREATE (p2:Person {name: "Riya"});
CREATE (p3:Person {name: "Kabir"});
CREATE (c:Company {name: "Tech Solutions"});

MATCH (a:Person {name: "Aman"}), (b:Person {name: "Riya"})
CREATE (a)-[:FRIENDS_WITH]->(b);
MATCH (a:Person {name: "Aman"}), (b:Person {name: "Kabir"})
CREATE (a)-[:FOLLOWS]->(b);
MATCH (p:Person {name: "Riya"}), (c:Company {name: "Tech Solutions"})
CREATE (p)-[:WORKS_AT]->(c);

MATCH (:Person {name: "Aman"})-[:FRIENDS_WITH]-(friend:Person)
RETURN friend.name AS friend;

MATCH (follower:Person)-[:FOLLOWS]->(:Person {name: "Kabir"})
RETURN follower.name AS follower;
