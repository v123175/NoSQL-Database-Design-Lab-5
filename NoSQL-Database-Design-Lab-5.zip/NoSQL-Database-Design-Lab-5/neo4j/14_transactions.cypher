CREATE (p:Product {product_id: "P100", name: "Keyboard", price: 1200});

BEGIN;
MATCH (p:Product {product_id: "P100"})
SET p.price = 1100;
CREATE (:AuditLog {action: "PRICE_UPDATED", product_id: "P100", changed_at: datetime()});
MATCH (p:Product {product_id: "P100"})
RETURN p;
COMMIT;

BEGIN;
MATCH (p:Product {product_id: "P100"})
SET p.stock = 25;
MATCH (p:Product {product_id: "P100"})
RETURN p;
COMMIT;

MATCH (p:Product {product_id: "P100"})
DELETE p;
