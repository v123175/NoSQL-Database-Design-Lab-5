CREATE (customer:Customer {customer_id: "CU01", name: "Aman"});
CREATE (category:Category {category_id: "CA01", name: "Electronics"});
CREATE (product1:Product {product_id: "P01", name: "Laptop", price: 55000});
CREATE (product2:Product {product_id: "P02", name: "Mouse", price: 700});
CREATE (order:Order {order_id: "O01", order_date: date()});

MATCH (p:Product), (c:Category {category_id: "CA01"})
CREATE (p)-[:BELONGS_TO]->(c);

MATCH (cu:Customer {customer_id: "CU01"}), (o:Order {order_id: "O01"})
CREATE (cu)-[:PLACED]->(o);

MATCH (o:Order {order_id: "O01"}), (p:Product {product_id: "P01"})
CREATE (o)-[:CONTAINS {quantity: 1}]->(p);

MATCH (cu:Customer {name: "Aman"})-[:PLACED]->(:Order)-[:CONTAINS]->(p:Product)
RETURN DISTINCT p.name AS purchased_product, p.price AS price;
