import requests
import json

BASE = "http://localhost:8098"
BUCKET = "user_profiles"

profile = {
    "name": "Aman",
    "email": "aman@example.com",
    "city": "Roorkee",
    "language": "English",
    "theme": "dark",
    "notifications": {"email": True, "sms": False}
}

put = requests.put(
    f"{BASE}/buckets/{BUCKET}/keys/user_1",
    data=json.dumps(profile),
    headers={"Content-Type": "application/json"}
)
put.raise_for_status()

get = requests.get(f"{BASE}/buckets/{BUCKET}/keys/user_1")
get.raise_for_status()
print(get.json())
