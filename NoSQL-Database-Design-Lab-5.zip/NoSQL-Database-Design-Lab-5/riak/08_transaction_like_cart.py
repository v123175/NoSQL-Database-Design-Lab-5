import requests
import json

BASE = "http://localhost:8098"
BUCKET = "shopping_carts"
KEY = "transaction_like_cart"
URL = f"{BASE}/buckets/{BUCKET}/keys/{KEY}"

def read_cart():
    response = requests.get(URL)
    if response.status_code == 404:
        return {"items": [], "total": 0}
    response.raise_for_status()
    return response.json()

def write_cart(cart):
    response = requests.put(
        URL, data=json.dumps(cart),
        headers={"Content-Type": "application/json"}
    )
    response.raise_for_status()

cart = read_cart()
cart["items"].append({"product_id": "P10", "quantity": 1, "price": 250})
write_cart(cart)

cart = read_cart()
cart["items"][0]["quantity"] = 2
cart["total"] = sum(x["quantity"] * x["price"] for x in cart["items"])
write_cart(cart)

print(read_cart())
