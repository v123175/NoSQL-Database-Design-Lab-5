import requests
import json

BASE = "http://localhost:8098"
BUCKET = "data_types"

values = {
    "string_value": "Hello Riak",
    "json_value": {"name": "Aman", "age": 20},
    "list_value": ["DBMS", "Python", "NoSQL"]
}

for key, value in values.items():
    response = requests.put(
        f"{BASE}/buckets/{BUCKET}/keys/{key}",
        data=json.dumps(value),
        headers={"Content-Type": "application/json"}
    )
    response.raise_for_status()

for key in values:
    response = requests.get(f"{BASE}/buckets/{BUCKET}/keys/{key}")
    response.raise_for_status()
    print(key, response.json())
