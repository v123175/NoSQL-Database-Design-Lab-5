import requests
import json
from datetime import datetime, timezone

BASE = "http://localhost:8098"
BUCKET = "user_sessions"

session = {
    "session_id": "sess_1001",
    "user_id": "user_25",
    "login_time": datetime.now(timezone.utc).isoformat(),
    "status": "active"
}

response = requests.put(
    f"{BASE}/buckets/{BUCKET}/keys/{session['session_id']}",
    data=json.dumps(session),
    headers={"Content-Type": "application/json"}
)
response.raise_for_status()

response = requests.get(f"{BASE}/buckets/{BUCKET}/keys/sess_1001")
response.raise_for_status()
print(response.json())
