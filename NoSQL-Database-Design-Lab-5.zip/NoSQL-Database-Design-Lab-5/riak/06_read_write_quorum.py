import requests
import json

BASE = "http://localhost:8098"
BUCKET = "quorum_demo"
KEY = "record_1"

write = requests.put(
    f"{BASE}/buckets/{BUCKET}/keys/{KEY}?w=2&dw=2",
    data=json.dumps({"value": "consistent write"}),
    headers={"Content-Type": "application/json"}
)
write.raise_for_status()

read = requests.get(f"{BASE}/buckets/{BUCKET}/keys/{KEY}?r=2")
read.raise_for_status()
print(read.json())
