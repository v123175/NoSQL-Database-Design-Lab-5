import requests
import json

BASE = "http://localhost:8098"
BUCKET = "shopping_carts"
KEY = "user_1_cart"
URL = f"{BASE}/buckets/{BUCKET}/keys/{KEY}"

def load_cart():
    response = requests.get(URL)
    if response.status_code == 404:
        return {"user_id": "user_1", "items": [], "total": 0}
    response.raise_for_status()
    return response.json()

def save_cart(cart):
    cart["total"] = sum(item["quantity"] * item["price"] for item in cart["items"])
    response = requests.put(
        URL, data=json.dumps(cart),
        headers={"Content-Type": "application/json"}
    )
    response.raise_for_status()

def add_product(product_id, quantity, price):
    cart = load_cart()
    for item in cart["items"]:
        if item["product_id"] == product_id:
            item["quantity"] += quantity
            break
    else:
        cart["items"].append({
            "product_id": product_id, "quantity": quantity, "price": price
        })
    save_cart(cart)

def update_quantity(product_id, quantity):
    cart = load_cart()
    for item in cart["items"]:
        if item["product_id"] == product_id:
            item["quantity"] = quantity
            break
    save_cart(cart)

def remove_product(product_id):
    cart = load_cart()
    cart["items"] = [x for x in cart["items"] if x["product_id"] != product_id]
    save_cart(cart)

add_product("P101", 2, 499)
update_quantity("P101", 3)
print(load_cart())
remove_product("P101")
print(load_cart())
