import requests
import json

BASE = "http://localhost:8098"
BUCKET = "user_sets"
KEY = "interests_user_1"
URL = f"{BASE}/buckets/{BUCKET}/keys/{KEY}"

def load_set():
    response = requests.get(URL)
    if response.status_code == 404:
        return set()
    response.raise_for_status()
    return set(response.json())

def save_set(values):
    response = requests.put(
        URL, data=json.dumps(sorted(values)),
        headers={"Content-Type": "application/json"}
    )
    response.raise_for_status()

interests = load_set()
interests.update({"music", "sports", "coding"})
save_set(interests)

interests.discard("music")
save_set(interests)

print("Membership:", "coding" in load_set())

other_user_interests = {"sports", "reading", "coding"}
print("Common:", load_set().intersection(other_user_interests))
