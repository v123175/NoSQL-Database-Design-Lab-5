import requests
import json

BASE = "http://localhost:8098"
BUCKETS = ["students", "products", "orders"]

for bucket in BUCKETS:
    for index in range(1000):
        record = {
            "id": index,
            "bucket": bucket,
            "name": f"{bucket}_record_{index}"
        }
        response = requests.put(
            f"{BASE}/buckets/{bucket}/keys/{bucket}_{index}",
            data=json.dumps(record),
            headers={"Content-Type": "application/json"}
        )
        response.raise_for_status()

print("Inserted 3000 records")
