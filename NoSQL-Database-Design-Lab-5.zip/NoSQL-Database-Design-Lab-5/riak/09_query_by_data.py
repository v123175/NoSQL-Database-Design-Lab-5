import requests
import json

BASE = "http://localhost:8098"
BUCKET = "users"

users = [
    {"name": "Aman", "city": "Roorkee", "age": 20, "preferences": ["music", "sports"]},
    {"name": "Riya", "city": "Delhi", "age": 22, "preferences": ["reading"]},
    {"name": "Kabir", "city": "Roorkee", "age": 21, "preferences": ["sports"]}
]

for index, user in enumerate(users):
    response = requests.put(
        f"{BASE}/buckets/{BUCKET}/keys/user_{index}",
        data=json.dumps(user),
        headers={"Content-Type": "application/json"}
    )
    response.raise_for_status()

def find_users(city=None, min_age=None, preference=None):
    matches = []
    for index in range(len(users)):
        response = requests.get(f"{BASE}/buckets/{BUCKET}/keys/user_{index}")
        response.raise_for_status()
        user = response.json()
        if city and user.get("city") != city:
            continue
        if min_age and user.get("age", 0) < min_age:
            continue
        if preference and preference not in user.get("preferences", []):
            continue
        matches.append(user)
    return matches

print(find_users(city="Roorkee", min_age=20, preference="sports"))
