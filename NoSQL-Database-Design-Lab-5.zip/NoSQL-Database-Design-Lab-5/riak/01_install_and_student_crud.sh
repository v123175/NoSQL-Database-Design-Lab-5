#!/usr/bin/env bash
set -euo pipefail
docker run -d --name riak -p 8087:8087 -p 8098:8098 basho/riak-kv:latest
until curl -fsS http://localhost:8098/ping >/dev/null; do sleep 2; done
curl -i -X PUT http://localhost:8098/buckets/students/props \
  -H "Content-Type: application/json" \
  -d '{"props":{"allow_mult":false}}'
curl -i -X PUT http://localhost:8098/buckets/students/keys/student1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Aman","roll_no":101,"course":"BCA"}'
curl -i http://localhost:8098/buckets/students/keys/student1
curl -i -X PUT http://localhost:8098/buckets/students/keys/student1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Aman Kumar","roll_no":101,"course":"BCA"}'
curl -i -X DELETE http://localhost:8098/buckets/students/keys/student1
