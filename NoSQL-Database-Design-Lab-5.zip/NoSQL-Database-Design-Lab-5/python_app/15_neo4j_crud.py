import os
from neo4j import GraphDatabase

URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
USER = os.getenv("NEO4J_USER", "neo4j")
PASSWORD = os.getenv("NEO4J_PASSWORD", "password")

class StudentGraph:
    def __init__(self):
        self.driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))

    def close(self):
        self.driver.close()

    def create_student(self, student_id, name, city):
        query = """
        MERGE (s:Student {student_id: $student_id})
        SET s.name = $name, s.city = $city
        RETURN s
        """
        with self.driver.session() as session:
            return session.run(
                query, student_id=student_id, name=name, city=city
            ).single()

    def read_student(self, student_id):
        query = "MATCH (s:Student {student_id: $student_id}) RETURN s"
        with self.driver.session() as session:
            record = session.run(query, student_id=student_id).single()
            return record["s"] if record else None

    def update_city(self, student_id, city):
        query = """
        MATCH (s:Student {student_id: $student_id})
        SET s.city = $city
        RETURN s
        """
        with self.driver.session() as session:
            return session.run(query, student_id=student_id, city=city).single()

    def delete_student(self, student_id):
        query = """
        MATCH (s:Student {student_id: $student_id})
        DETACH DELETE s
        """
        with self.driver.session() as session:
            session.run(query, student_id=student_id)

    def enroll(self, student_id, course_name):
        query = """
        MATCH (s:Student {student_id: $student_id})
        MERGE (c:Course {name: $course_name})
        MERGE (s)-[:ENROLLED_IN]->(c)
        RETURN s, c
        """
        with self.driver.session() as session:
            return session.run(
                query, student_id=student_id, course_name=course_name
            ).single()

    def courses_for_student(self, student_id):
        query = """
        MATCH (s:Student {student_id: $student_id})-[:ENROLLED_IN]->(c:Course)
        RETURN c.name AS course
        """
        with self.driver.session() as session:
            return [r["course"] for r in session.run(query, student_id=student_id)]

if __name__ == "__main__":
    app = StudentGraph()
    try:
        app.create_student("S100", "Aman", "Roorkee")
        print(app.read_student("S100"))
        app.update_city("S100", "Dehradun")
        app.enroll("S100", "NoSQL Database")
        print(app.courses_for_student("S100"))
        app.delete_student("S100")
    finally:
        app.close()
